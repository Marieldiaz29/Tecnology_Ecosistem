# Reporte de Resultados — Proyecto "Leer DTH11"

**Alumno:**
**Materia:** Desarrollo Sustentable con Automatización
**Institución:** Instituto Tecnológico de Mazatlán
**Fecha:**

> Nota: este archivo es una plantilla en Markdown. Debe completarse y exportarse/imprimirse como PDF para colocarlo en esta misma carpeta (`resultados/reporte_resultados.pdf`), según lo solicita la rúbrica.

---

## 1. Resumen de la práctica

Describir en 3-4 líneas en qué consistió la práctica (Arduino UNO R4 WiFi + DHT11 + Make.com + Telegram).

## 2. Evidencias obtenidas

- [ ] Captura del escenario completo en Make.com
- [ ] Captura de cada módulo con los filtros visibles
- [ ] Captura del mensaje recibido en Telegram
- [ ] Enlace al video de la prueba en vivo

## 3. Datos de prueba registrados

| # de prueba | Temperatura (°C) | Humedad (%) | ¿Se activó la alerta? | Hora |
|---|---|---|---|---|
| 1 |  |  |  |  |
| 2 |  |  |  |  |
| 3 |  |  |  |  |

## 4. Conclusiones

Redactar las conclusiones personales sobre lo aprendido durante la práctica.

## 5. Aprendizajes obtenidos

- Aprendizaje 1
- Aprendizaje 2
- Aprendizaje 3

## 6. Dificultades encontradas y solución

Describir cualquier problema técnico (ej. errores de conexión, configuración del webhook, del bot de Telegram, etc.) y cómo se resolvió.
