# Tecnology_Ecosistem

Repositorio del proyecto de automatización **"Leer DHT11"**: integración de un sensor de temperatura y humedad (DHT11) con un Arduino UNO R4 WiFi, un escenario de **Make.com** y un **Bot de Telegram** para el envío de alertas en tiempo real.

**Materia:** Desarrollo Sustentable con Automatización
**Institución:** Instituto Tecnológico de Mazatlán

---

## 📁 Estructura del repositorio

```
Tecnology_Ecosistem/
├── README.md
├── codigo/
│   └── blueprint.json
├── imagenes/
│   └── (capturas del escenario de Make)
├── video/
│   └── enlace.txt
└── resultados/
    └── reporte_resultados.md
```

---

## 1. Introducción

El presente proyecto documenta el desarrollo de un ecosistema tecnológico de automatización que conecta un microcontrolador físico (Arduino) con servicios en la nube (Make.com) y una aplicación de mensajería (Telegram), con el propósito de monitorear condiciones ambientales y generar alertas automáticas cuando se superan ciertos umbrales.

## 2. Objetivo

Diseñar, implementar y documentar un sistema capaz de:
- Leer datos de temperatura y humedad mediante un sensor DHT11.
- Enviar esos datos a Make.com a través de un webhook.
- Procesar la información con un escenario de automatización que incluya filtros condicionales.
- Notificar al usuario mediante un Bot de Telegram cuando la temperatura supere un umbral definido.

## 3. Materiales y herramientas

| Componente | Descripción |
|---|---|
| Arduino UNO R4 WiFi | Microcontrolador con conectividad WiFi integrada |
| Sensor DHT11 | Sensor digital de temperatura y humedad |
| Make.com | Plataforma de automatización (iPaaS) |
| Telegram Bot API | Servicio de mensajería para notificaciones |
| Cables Dupont / Protoboard | Conexión física del sensor |

## 4. Desarrollo de la práctica

### 4.1 Conexión física
El sensor DHT11 se conecta al Arduino UNO R4 WiFi mediante tres pines: VCC (5V), GND y el pin de datos a una entrada digital. Se utiliza una resistencia pull-up (si el módulo no la incluye) entre VCC y el pin de datos.

### 4.2 Programación del Arduino
Se carga un sketch que:
1. Inicializa la librería del sensor DHT11.
2. Lee periódicamente temperatura y humedad.
3. Envía los datos mediante una petición HTTP (webhook) hacia Make.com.

### 4.3 Escenario en Make.com
El escenario "Leer DTH11" está compuesto por los siguientes módulos:
1. **Webhook (Custom webhook):** recibe los datos enviados por el Arduino.
2. **Filtro condicional:** evalúa si la temperatura recibida supera el umbral establecido.
3. **Telegram Bot – Send a Text Message:** envía la alerta al chat configurado cuando se cumple la condición del filtro.

> Las capturas de pantalla de cada módulo, mostrando los filtros configurados, se encuentran en la carpeta `imagenes/`.

### 4.4 Configuración del Bot de Telegram
Se crea un bot mediante **BotFather**, se obtiene el token de acceso y se vincula al módulo correspondiente dentro del escenario de Make, configurando el `chat_id` de destino.

## 5. Resultados

El sistema fue probado en condiciones reales, confirmando que:
- Los datos del sensor DHT11 llegan correctamente al webhook de Make.
- El filtro condicional discrimina correctamente los valores que superan el umbral.
- Las notificaciones llegan a Telegram en tiempo real, sin retrasos significativos.

La evidencia en video de la prueba en vivo se encuentra referenciada en `video/enlace.txt`.

## 6. Preguntas de reflexión

**¿Qué ventajas ofrece automatizar la lectura de sensores mediante plataformas en la nube como Make.com?**
Permite desacoplar la lógica de negocio del hardware, facilita la integración con múltiples servicios (mensajería, bases de datos, correo) sin necesidad de programar cada integración manualmente, y reduce el tiempo de desarrollo.

**¿Qué papel juegan los filtros dentro de un escenario de automatización?**
Los filtros permiten que el flujo de datos solo continúe hacia las siguientes acciones cuando se cumplen condiciones específicas, evitando notificaciones innecesarias y optimizando el uso de recursos (ejecuciones/operaciones consumidas en la plataforma).

**¿Qué aplicaciones reales tiene este tipo de ecosistema (IoT + automatización + mensajería)?**
Monitoreo ambiental en invernaderos, sistemas de alerta temprana en almacenes o centros de datos, control de cadena de frío en logística, y monitoreo remoto de espacios habitacionales, entre otros.

**¿Qué mejoras se podrían implementar a futuro?**
Agregar almacenamiento histórico de los datos (por ejemplo, en Google Sheets o una base de datos), incorporar un dashboard de visualización, y añadir múltiples umbrales o niveles de alerta (advertencia/crítico).

## 7. Conclusión

El proyecto permitió comprender de forma práctica cómo se integran dispositivos físicos (IoT) con plataformas de automatización en la nube, evidenciando la utilidad de estas herramientas para construir soluciones de monitoreo accesibles, sin necesidad de infraestructura backend propia.

---

## 📂 Contenido de las carpetas

- **`codigo/blueprint.json`** — Exportación del escenario de Make.com, listo para importar.
- **`imagenes/`** — Capturas del escenario completo y de cada módulo con los filtros visibles.
- **`video/enlace.txt`** — Enlace a la demostración en video en YouTube.
- **`resultados/reporte_resultados.md`** — Plantilla del reporte de conclusiones en PDF.
